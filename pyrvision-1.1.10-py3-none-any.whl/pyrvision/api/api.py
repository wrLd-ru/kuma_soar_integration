import json
from typing import Union, List

from .base import BaseAPI


USER_FIELDS = (
    "id", "uuid", "login", "name", "fio", "display_name",
    "email", "phone", "post", "department", "last_logon",
    "disabled", "disabled_at", "use_preset_interface",
    "interface_group_id", "all_companies", "use_mobile_arm",
    "user_status", "groups", "user_groups_id",
    "companies_id", "companies", "service_account",
    "roles", "createdAt", "updatedAt"
)
COMPANY_FIELDS = (
    "uuid", "id", "name", "settings", "createdAt", "updatedAt"
)
USER_GROUP_FIELDS = (
    "id", "name", "description", "default_interface_user_id",
    "fixed_tabs", "all_companies", "uuid", "company_ids",
    "companies", "roles", "updatedAt", "createdAt"
)
CUSTOM_ASSETS_FIELDS = (
    "id", "uuid", "name", "company", "description", "admin",
    "owner", "auditor", "links", "updatedAt"
)

ORGANIZATION_FIELDS = ("uuid", "type_id", "name", "parent_name",
                       "links", "id", "company_id", "company", "admin",
                       "auditor", "description", "compliance_manager",
                       "updatedAt")


class RvisionAPI(BaseAPI):

    @property
    def me(self):
        return self.request('get', 'api/v2/tokens/get_info_by_token')

    def get_incidents(self,
                      fields: list = None,
                      filters: list = None,
                      sort: list = None,
                      limit: int = None,
                      offset: int = None) -> List[dict]:
        data = {
            'fields': json.dumps(fields) if fields else None,
            'filter': json.dumps(filters) if filters else None,
            'sort': json.dumps(sort) if sort else None,
            'limit': limit,
            'offset': offset
        }
        response = self.request('get', 'api/v2/incidents', params=self._sanitize_data(data))['data']['result']

        return response

    def create_update_incident(self, data):
        response = self.request('post', 'api/v2/incidents', data=data)
        return response['data'][0]

    def add_file_to_incident(self, uuid: str, file: bytes, filename: [str], mime: [str]):
        headers = {'content-type': None}
        payload = {'uuid': uuid}

        files = [(
            'files', (
                filename,
                file,
                mime
            )
        )]

        response = self.request("POST",
                                'api/v2/incidents',
                                headers=headers,
                                payload=payload,
                                files=files)
        return response

    def get_linked_incidents(self, identifier):
        response = self.request('get', f'api/v2/incidents/{identifier}/incidents')
        return response['data']['result']

    def get_files_metadata_of_incident(self, identifier):
        response = self.request('get', f'api/v2/incidents/{identifier}/files')
        return response['data']

    def get_file_by_id(self, id_):
        response = self.request('get', f'api/v2/incidents/files/{id_}/download')
        return response

    def get_comments(self, identifier):
        response = self.request('get', f'api/v2/incidents/{identifier}/comments')
        return response['data']

    def send_comments(self, identifier, text):
        data = {
            "identifier": identifier,
            "data": {
                "comment": text
            }
        }
        response = self.request('post', f'api/v2/comments', data=data)
        return response

    def link_incident(self,
                      identifier_linking: str,
                      identifier_linked: str,
                      link: str):
        data = {
            "links": [
                {
                    "incident": identifier_linked,
                    "link": link
                }
            ]
        }
        response = self.request(
            method='post',
            url=f'api/v2/incidents/{identifier_linking}/incidents',
            data=data
        )
        return response

    def get_users(self,
                  fields: list = None,
                  filters: list = None,
                  sort: list = None,
                  limit: int = 1000,
                  start: int = 0) -> [dict]:
        data = {
            'fields': fields if fields else USER_FIELDS,
            'filter': json.dumps(filters) if filters else None,
            'sort': json.dumps(sort) if sort else None,
            'limit': limit,
            'start': start
        }
        response = self.request('get', 'api/v2/users', params=self._sanitize_data(data))['data']

        return response

    def create_user(self, data):
        data = {'values': data}
        response = self.request('post', 'api/v2/users', data=data)["object"]
        return response

    def update_user(self, uuid, data):
        data = {
            'uuid': uuid,
            'values': data
        }
        response = self.request('put', 'api/v2/users', data=data)["object"]
        return response

    def get_roles(self,
                  filters: list = None,
                  sort: str = None,
                  limit: int = 1000,
                  start: int = 0) -> List[dict]:
        data = {
            'filter': json.dumps(filters) if filters else None,
            'sort': json.dumps(sort) if sort else None,
            'limit': limit,
            'start': start
        }
        response = self.request('get', 'api/v2/roles', params=self._sanitize_data(data))['data']

        return response

    def get_companies(self,
                      fields: list = None,
                      filters: list = None,
                      sort: str = None,
                      limit: int = 1000,
                      start: int = 0) -> List[dict]:
        data = {
            'fields': fields if fields else COMPANY_FIELDS,
            'filter': json.dumps(filters) if filters else None,
            'sort': sort,
            'limit': limit,
            'start': start
        }
        response = self.request('get', 'api/v2/companies', params=self._sanitize_data(data))['data']

        return response

    def get_user_groups(self,
                        fields: list = None,
                        filters: list = None,
                        sort: list = None,
                        limit: int = 1000,
                        start: int = 0) -> List[dict]:
        data = {
            'fields': json.dumps(fields) if fields else USER_GROUP_FIELDS,
            'filter': json.dumps(filters) if filters else None,
            'sort': sort,
            'limit': limit,
            'start': start
        }
        response = self.request('get', 'api/v2/user_groups', params=self._sanitize_data(data))['data']

        return response

    def create_user_group(self, data):
        data = {'values': data}
        response = self.request('post', 'api/v2/user_groups', data=data)['object']

        return response

    def get_tasks(self,
                  fields: list = None,
                  filters: list = None,
                  sort: list = None,
                  limit: int = 1000,
                  offset: int = 0):
        data = {
            'fields': json.dumps(fields) if fields else None,
            'filters': json.dumps(filters) if filters else None,
            'sorts': sort,
            'limit': limit,
            'offset': offset,
        }
        response = self.request('get', 'api/v2/tasks', params=self._sanitize_data(data))['result']

        return response

    def create_task(self, data):
        response = self.request('post', 'api/v2/tasks', data=data)['result']
        return response

    def update_task(self, uuid, data):
        response = self.request('put', f'api/v2/tasks/{uuid}', data=data)['result']
        return response

    def get_task_types(self,
                       fields: list = None,
                       filters: list = None,
                       sort: list = None,
                       limit: int = 1000,
                       offset: int = 0):
        data = {
            'fields': json.dumps(fields) if fields else None,
            'filters': json.dumps(filters) if filters else None,
            'sorts': sort,
            'limit': limit,
            'offset': offset,
        }
        response = self.request('get', 'api/v2/tasks/types', params=self._sanitize_data(data))['result']

        return response

    def get_custom_assets_types(self):
        response = self.request('get', 'api/v2/am/custom/')['data']
        return response

    def get_custom_assets(self,
                          type_id: int,
                          fields: list = None,
                          filters: list = None,
                          sort: list = None,
                          limit: int = None,
                          start: int = None):
        data = {
            'fields': json.dumps(fields) if fields else CUSTOM_ASSETS_FIELDS,
            'filter': json.dumps(filters) if filters else None,
            'sort': json.dumps(sort) if sort else None,
            'limit': limit,
            'start': start
        }
        response = self.request('get', f'api/v2/am/custom/{type_id}', params=self._sanitize_data(data))

        return response['data']

    def create_custom_asset(self, assets_type, data):
        response = self.request('post', f'api/v2/am/custom/{assets_type}', data=data)

        return {'uuid': response['object'][0]['uuid']}

    def update_custom_asset(self, assets_type, uuid, data):
        params = {
            'uuid': uuid
        }
        response = self.request('put', f'api/v2/am/custom/{assets_type}', params=params, data=data)

        return {'uuid': response['object'][0]['uuid']}

    def get_custom_assets_changes_log(self,
                                      assets_type: int,
                                      limit: int = None,
                                      start: int = None,
                                      uuid: str = None,
                                      actions: list = None,
                                      timestamp: str = None):
        data = {
            'limit': limit,
            'start': start,
            'uuid': uuid,
            'actions': actions,
            'timestamp': timestamp
        }
        response = self.request('get', f'api/v2/am/custom/{assets_type}/diff', params=self._sanitize_data(data))

        return response['data']

    def get_organization(self,
                         fields: list = None,
                         filters: list = None,
                         sort: list = None,
                         limit: int = None,
                         start: int = None):
        data = {
            'fields': json.dumps(fields) if fields else ORGANIZATION_FIELDS,
            'filter': json.dumps(filters) if filters else None,
            'sort': json.dumps(sort) if sort else None,
            'limit': limit,
            'start': start
        }
        response = self.request('get', f'api/v2/am/organization', params=self._sanitize_data(data))['data']

        return response

    def create_organization(self, data):
        response = self.request('post', 'api/v2/am/organization', data=data)
        return response

    def update_organization(self, uuid, data):
        response = self.request('put', f'api/v2/am/organization/{uuid}', data=data)
        return response

    def delete_organization(self, uuid):
        self.request('delete', f'api/v2/am/organization?uuid={uuid}')

    def get_documents(self,
                      fields: list = None,
                      filters: list = None,
                      sorts: list = None,
                      limit: int = None,
                      offset: int = None):
        data = {
            'fields': json.dumps(fields) if fields else None,
            'filters': json.dumps(filters) if filters else None,
            'sorts': json.dumps(sorts) if sorts else None,
            'limit': limit,
            'offset': offset
        }
        response = self.request('get', 'api/v2/documents', params=self._sanitize_data(data))

        return response['result']

    def create_documents(self, data):
        response = self.request('post', 'api/v2/documents', data=data)
        return response['result']

    def update_document(self, uuid, data):
        response = self.request('put', f'api/v2/documents/{uuid}', data=data)
        return response['result']

    def get_documents_types(self,
                            fields: list = None,
                            filters: list = None,
                            sorts: list = None,
                            limit: int = None,
                            offset: int = None):
        data = {
            'fields': json.dumps(fields) if fields else None,
            'filters': json.dumps(filters) if filters else None,
            'sorts': json.dumps(sorts) if sorts else None,
            'limit': limit,
            'offset': offset
        }
        response = self.request('get', 'api/v2/documents/types', params=self._sanitize_data(data))

        return response['result']

    def get_document_type_params(self, uuid: str):
        response = self.request('get', f'api/v2/documents/types/{uuid}')
        return response['result']

    @staticmethod
    def _sanitize_data(data: dict):
        sanitize_data = {}
        for key, value in data.items():
            if value is not None:
                sanitize_data[key] = value

        return sanitize_data
