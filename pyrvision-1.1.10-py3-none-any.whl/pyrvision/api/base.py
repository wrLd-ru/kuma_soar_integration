import json
import logging
import urllib3
import requests
from http import HTTPStatus
from typing import Union

from ..utils import exceptions

log = logging.getLogger(__name__)

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class MetaSingleton(type):
    _instance = None

    def __call__(cls, *args, **kwargs):
        if not cls._instance or (args or kwargs):
            cls._instance = type.__call__(cls, *args, **kwargs)
        return cls._instance


class BaseAPI(metaclass=MetaSingleton):
    def __init__(
            self,
            host: str = None,
            token: str = None,
            protocol: str = 'https',
            verify: Union[str, bool] = False):
        self.url = self.__resolve_url(host, protocol)
        self.session = self.__get_session(token, verify)

    def request(self, method, url, params=None, data=None, files=None, headers=None, payload=None):
        data = json.dumps(data) if data else None
        data = payload if payload else data
        uri = self.url + url
        response = self.session.request(method, uri,
                                        params=params,
                                        data=data,
                                        files=files,
                                        headers=headers)
        response = self.__check_response(response)

        return response

    @staticmethod
    def __get_session(token: str, verify: Union[bool, str]):
        session = requests.session()
        session.headers = {
            'X-Token': token,
            'content-type': 'application/json'
        }
        session.verify = verify

        return session

    @staticmethod
    def __check_response(response):
        body = response.text
        url = response.request.url
        request = response.request
        method = response.request.method
        status_code = response.status_code

        # Если возвращается файл
        if not response.headers.get("Content-Disposition"):
            try:
                response_content = json.loads(body)
            except ValueError:
                response_content = {}
            log.debug(f'Response for ({method}) {url}: [{status_code}] {body}')
        else:
            response_content = response.content
            log.debug(f'Response for ({method}) {url}: [{status_code}]')

        try:
            error_message = response_content['error']
        except (TypeError, KeyError):
            error_message = None

        if HTTPStatus.OK <= status_code < HTTPStatus.MULTIPLE_CHOICES:
            return response_content
        elif status_code == HTTPStatus.BAD_REQUEST:
            raise exceptions.BadRequest(request, body)
        elif status_code == HTTPStatus.NOT_FOUND:
            raise exceptions.NotFound(request, "Api method does not exist")
        else:
            if error_message:
                raise exceptions.RequestError(request, error_message)
            raise exceptions.RequestError(request, body)

    @staticmethod
    def __resolve_url(host, protocol):
        return f'{protocol}://{host}/'




