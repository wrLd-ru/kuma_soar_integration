import abc
import datetime
import ipaddress
from typing import Any, Union

from ..utils.exceptions import TryToSetImmutableField
from ..utils.exceptions import TransformError
from ..utils.exceptions import SerializeError
from ..utils.exceptions import DeserializeError
from ..utils.exceptions import ObjectToPythonIsAbsent
from ..utils.exceptions import PrimaryFieldNotExist
from ..utils.exceptions import FormatTransformError


class BaseField(metaclass=abc.ABCMeta):
    def __init__(self,
                 name: str = None,
                 base: Union[type, str] = None,
                 primary: bool = False,
                 display: bool = False,
                 immutable: bool = False,
                 import_only: bool = False,
                 on_change: str = None,
                 export_fields: list = None,
                 export_key: str = None,
                 aliases: dict = None):
        """
        Инициализация базового поля
        :param name: Имя поля (заполняется автоматически)
        :param base: base: класс объекта RVision
        :param primary: Является ли поле ключевым?
        :param display_name: Отображать ли это поле в repr?
        :param immutable: Является ли поле неизменяемым?
        :param import_only: Поле можно импортировать, но не экспортировать.
        :param on_change: Метод целевого объекта, который будет вызван при изменении поля.
        :param export_fields: поля, которые нужно извлечь при экспорте (по умолчанию: все).
        :param export_key: имя поля, значением которого нужно подменить объект при экспорте.
        :param aliases: псевдонимы, для преобразования.
        """
        self.name = name
        self.base = base
        self.primary = primary
        self.display = display
        self.immutable = immutable
        self.import_only = import_only
        self.on_change = on_change
        self.export_fields = export_fields if export_fields else []
        self.export_key = export_key
        self.aliases = aliases if aliases else {}

    def __set_name__(self, owner, name):
        self.name = self.name if self.name else name

    def __get__(self, instance, owner):
        if instance is not None:
            return self.get_value(instance)
        else:
            return self.name

    def __set__(self, instance, value):
        if self.immutable:
            raise TryToSetImmutableField(self.name, value)
        self.set_value(instance, value)

    def __repr__(self):
        return f'{self.__class__.__name__}({self.name})'

    def get_value(self, instance):
        """
        Метод извлечения значения поля.
        Если поле пустое, пытаемся получить его выполнив запрос.
        :param instance: целевой объект
        :return:
        """
        value = instance.values.get(self.name)

        if value is None and not self.primary:
            try:
                instance.sync()
                value = instance.values.get(self.name)
            except PrimaryFieldNotExist:
                pass

        return value

    def set_value(self, instance, value, sync=False):
        """
        Метод, реализующий установку значения поля и запуск действия при изменении.
        :param instance: целевой объект
        :param value: устанавливаемое значение
        :param sync: статус синхронизации
        :return:
        """
        if value is not None:
            value = self._deserialize(value)

        instance.values[self.name] = value

        if self.on_change and hasattr(instance, self.on_change):
            getattr(instance, self.on_change)()

        instance.is_sync = sync

    def export(self, instance):
        """
        Метод, возвращающий сериализованное значение поля
        :param instance: целевой объект
        :return:
        """
        return self._serialize(self.get_value(instance))

    def _serialize(self, value):
        try:
            value = self.serialize(value)
        except Exception as e:
            raise SerializeError(self.name, value, type=type(self)) from e
        return value

    def _deserialize(self, value):
        try:
            value = self.deserialize(value)
        except Exception as e:
            raise DeserializeError(self.name, value, type=type(self)) from e
        return value

    @abc.abstractmethod
    def serialize(self, value):
        pass

    @abc.abstractmethod
    def deserialize(self, value):
        pass


class Field(BaseField):
    field_type: type = Any

    def serialize(self, value):
        return self.processing(value)

    def deserialize(self, value):
        return self.processing(value)

    def processing(self, value):
        """
        Обработка значения
        :param value: значение поля
        :return:
        """
        if self.field_type != Any:
            value = self.convert_type(value)
        self.check_value(value)
        return value

    def convert_type(self, value):
        """
        Преобразования значение в тип поля
        :param value: значение поля
        :return:
        """
        try:
            value = self.field_type(value)
        except ValueError:
            raise TransformError(self.name, value, type)
        return value

    def check_value(self, value):
        """
        Проверка значения на валидность в рамках Rvision
        :param value:
        :return:
        """
        pass


class IntField(Field):
    field_type: type = int


class FloatField(Field):
    field_type: type = float


class StrField(Field):
    field_type: type = str


class TextField(Field):
    field_type: type = str


class BoolField(Field):
    field_type: type = bool


class IpField(Field):
    field_type: type = str

    def check_value(self, value):
        try:
            ipaddress.IPv4Network(value)
        except ValueError:
            raise FormatTransformError(self.name, value, format='[0-255].[0-255].[0-255].[0-255]')


class DateTimeField(BaseField):
    def serialize(self, value):
        return f'{value.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]}Z'

    def deserialize(self, value):
        if not isinstance(value, datetime.datetime):
            try:
                return datetime.datetime.strptime(value, "%Y-%m-%dT%H:%M:%S.%fZ")
            except ValueError:
                return datetime.datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ")
        else:
            return value


class DictField(BaseField):
    def serialize(self, value):
        if self.aliases:
            value = self.mapping_aliases(value, reverse=True)

        if self.export_fields:
            return self.extract_export_field(value)

        if self.export_key:
            return self.extract_export_key(value)

        return value

    def deserialize(self, value):
        if self.aliases:
            value = self.mapping_aliases(value)

        return value

    def extract_export_field(self, value):
        """
        Экстракция определённых полей значения для экспорта.
        :param value: значение поля
        :return:
        """
        return {key: val for key, val in value.items() if key in self.export_fields}

    def extract_export_key(self, value):
        """
        Экстракция определённого значения поля в качестве значения для экспорта.
        :param value: значение поля
        :return:
        """
        return value[self.export_key]

    def mapping_aliases(self, value, reverse=False):
        """
        Метод, реализующий прямой и обратный маппинг полей
        :param value: значение поля
        :param reverse: обратное преобразование
        :return:
        """
        aliases = self.aliases
        if reverse:
            aliases = {val: key for key, val in aliases.items()}
        for alias, name in aliases.items():
            value[name] = value.pop(alias)
        return value


class ObjectField(DictField):
    def set_value(self, instance, value, sync=False):
        self.resolve_base(instance)
        super().set_value(instance, value, sync)

    def serialize(self, value):
        try:
            value = value.to_python()
        except AttributeError:
            raise ObjectToPythonIsAbsent

        return super().serialize(value)

    def deserialize(self, value):
        if isinstance(value, list):
            value = value[0]
        if isinstance(value, dict):
            value = self.mapping_aliases(value)
            value = self.base(value)

        return value

    def resolve_base(self, instance):
        if isinstance(self.base, str) and self.base == 'self':
            self.base = type(instance)


class CatalogField(DictField):
    def deserialize(self, value):
        if isinstance(value, dict):
            return super().deserialize(value)
        elif self.export_key:
            return {self.export_key: value}
        elif self.export_fields and len(self.export_fields) == 1:
            return {self.export_fields[0]: value}
        else:
            return value


class ListField(BaseField):
    def __init__(self, field_type=Field, *args, **kwargs):
        self.field_type = field_type
        self.args = args
        self.kwargs = kwargs
        super().__init__(*args, **kwargs)

    def get_value(self, instance):
        value = super().get_value(instance)
        return value if value else []

    def serialize(self, value):
        return self.transform(value, self.field_type(*self.args, **self.kwargs).serialize)

    def deserialize(self, value):
        return self.transform(value, self.field_type(*self.args, **self.kwargs).deserialize)

    @staticmethod
    def transform(value, func):
        return [func(item) for item in value]
