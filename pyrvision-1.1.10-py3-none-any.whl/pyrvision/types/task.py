from __future__ import annotations

from datetime import datetime
from typing import List, Union

from .. import api
from ..utils import Filter
from .fields import IntField, StrField, TextField, DateTimeField, ListField, ObjectField, CatalogField
from .base import RvisionObject
from .company import Company
from .incident import Incident
from .user import User
from .task_types import TaskType


class Task(RvisionObject):
    id: int = IntField(import_only=True)
    uuid: str = StrField(primary=True, import_only=True)
    name: str = StrField(display=True)
    description: str = TextField()
    create_time: datetime = DateTimeField(import_only=True)
    update_time: datetime = DateTimeField(import_only=True)
    due_time: datetime = DateTimeField()
    close_time: datetime = DateTimeField(import_only=True)
    rel: List[str] = ListField(field_type=StrField, import_only=True)
    parent_link: Task = ObjectField(base='self', export_fields=['id'])
    type: str = ObjectField(base=TaskType, export_fields=['uuid'])
    status: Union[dict, int] = CatalogField(export_fields=['id'])
    severity: Union[dict, int] = CatalogField(export_fields=['id'])
    reporter: User = ObjectField(base=User, export_fields=['id'])
    assignees: List[User] = ListField(field_type=ObjectField, base=User, export_fields=['id'])
    company: Company = ObjectField(base=Company, export_fields=['uuid'])
    incident: Incident = ObjectField(base=Incident, export_fields=['uuid'])

    @classmethod
    def objects(cls,
                filters: Union[Filter, list] = None,
                limit: int = 1000,
                offset: int = None,
                **kwargs):
        filters = cls._get_filter(filters, kwargs)
        response = api.RvisionAPI().get_tasks(filters=filters,
                                              limit=limit,
                                              offset=offset)

        return [cls(elem, sync=True) for elem in response]

    def _create(self):
        return self._api.create_task(self.to_python(export=True))

    def _update(self):
        return self._api.update_task(self.uuid, self.to_python(export=True))






