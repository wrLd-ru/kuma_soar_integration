from datetime import datetime
from typing import List, Union

from .. import api
from ..utils import Filter
from .base import RvisionObject
from .role import Role
from .company import Company
from .user_group import UserGroup
from .fields import IntField, StrField, BoolField, ObjectField, ListField, DateTimeField


class User(RvisionObject):
    id: int = IntField(primary=True)
    login: str = StrField(display=True)
    fio: str = StrField()
    name: str = StrField(import_only=True)
    display_name: str = StrField(immutable=True)
    email: str = StrField()
    post: str = StrField()
    department: str = StrField()
    last_logon: datetime = DateTimeField()
    disabled: bool = BoolField()
    disabled_at: datetime = DateTimeField()
    use_preset_interface: str = BoolField()
    interface_group_id: str = StrField()
    all_companies: bool = BoolField(immutable=True)
    use_mobile_arm: bool = BoolField()
    phone: str = StrField()
    user_status: str = StrField(immutable=True)
    groups: List[UserGroup] = ListField(field_type=ObjectField,
                                        base=UserGroup,
                                        on_change='_sync_user_groups',
                                        import_only=True)
    user_groups_id: List[int] = ListField(field_type=IntField)
    companies_id: List[int] = ListField(field_type=IntField)
    service_account: bool = BoolField()
    roles: List[Role] = ListField(field_type=ObjectField, base=Role, export_key='id')
    uuid: str = StrField(primary=True)
    createdAt: datetime = DateTimeField(immutable=True)
    updatedAt: datetime = DateTimeField(immutable=True)
    password: str = StrField()
    need_to_change_password: bool = BoolField()
    companies: List[Company] = ListField(field_type=ObjectField,
                                         base=Company,
                                         on_change='_sync_companies',
                                         import_only=True,
                                         export_fields=['uuid', 'id', 'name'])
    access_level: str = StrField()

    @classmethod
    def objects(cls,
                filters: Union[Filter, list] = None,
                limit: int = 1000,
                start: int = None,
                **kwargs):
        filters = cls._get_filter(filters, kwargs)
        response = api.RvisionAPI().get_users(filters=filters,
                                              limit=limit,
                                              start=start)

        return [cls(elem) for elem in response]

    def _create(self):
        return self._api.create_user(self.to_python(export=True))

    def _update(self):
        return self._api.update_user(self.uuid, self.to_python(export=True))

    def _sync_companies(self):
        if self.values.get('companies') is not None:
            self.companies_id = [company.id for company in self.companies]

    def _sync_user_groups(self):
        if self.values.get('groups') is not None:
            self.user_groups_id = [group.id for group in self.groups]
