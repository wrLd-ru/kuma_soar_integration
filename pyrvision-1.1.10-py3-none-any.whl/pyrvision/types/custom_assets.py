from typing import Union

from .. import api
from ..utils import Filter
from .base import RvisionObject
from .user import User
from .company import Company
from .custom_assets_type import CustomAssetsType
from .fields import IntField, StrField, TextField, ObjectField


class CustomAsset(RvisionObject):
    id: int = IntField(primary=True)
    uuid: str = StrField(primary=True)
    name: str = StrField(display=True)
    company: Company = ObjectField(base=Company, export_key='uuid')
    description: str = TextField()
    admin: User = ObjectField(base=User, export_key='id')
    owner: User = ObjectField(base=User, export_key='id')
    auditor: User = ObjectField(base=User, export_key='id')
    links: str = StrField()

    def __init__(self, asset_type: Union[CustomAssetsType, int, str], *args, **kwargs):
        self._asset_type = self.resolve_asset_type(asset_type)
        super().__init__(*args, **kwargs)

    @classmethod
    def objects(cls,
                asset_type: Union[CustomAssetsType, int, str],
                filters: Union[Filter, list] = None,
                limit: int = None,
                start: int = None,
                **kwargs):
        filters = cls._get_filter(filters, kwargs)
        fields = list(cls._get_fields().keys())
        type_id = asset_type.id if isinstance(asset_type, CustomAssetsType) else asset_type
        response = api.RvisionAPI().get_custom_assets(type_id=type_id,
                                                      fields=fields,
                                                      filters=filters,
                                                      limit=limit,
                                                      start=start)
        return [cls(asset_type=asset_type, values=elem, sync=True) for elem in response]

    def pull(self):
        return super().pull(asset_type=self._asset_type)

    def push(self):
        return super().push(asset_type=self._asset_type)

    def copy(self):
        return super().copy(asset_type=self._asset_type)

    def _create(self):
        return self._api.create_custom_asset(self._asset_type, data=self.to_python(export=True))

    def _update(self):
        return self._api.update_custom_asset(self._asset_type,
                                             uuid=self.uuid,
                                             data=self.to_python(export=True))

    def get_changes_log(self,
                        limit: int = None,
                        start: int = None,
                        actions: list = None,
                        timestamp: str = None):
        uuid = self.values.get('uuid')
        if uuid:
            response = self._api.get_custom_assets_changes_log(assets_type=self._asset_type,
                                                               uuid=uuid,
                                                               limit=limit,
                                                               start=start,
                                                               actions=actions,
                                                               timestamp=timestamp)
            return response

    @staticmethod
    def resolve_asset_type(asset_type: Union[CustomAssetsType, int, str]):
        if isinstance(asset_type, CustomAssetsType):
            return asset_type.id
        elif isinstance(asset_type, int):
            return asset_type
        elif isinstance(asset_type, str):
            asset_types = CustomAssetsType.objects(tag=asset_type)
            if asset_types:
                return asset_types[0].id
        raise TypeError('Невозможно определить тип кастомного актива')

