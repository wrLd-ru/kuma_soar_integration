from datetime import datetime
from typing import Union

from .. import api
from ..utils import Filter
from .fields import IntField, StrField, ListField, DictField
from .base import RvisionObject


class TaskType(RvisionObject):
    id: int = IntField(primary=True)
    uuid: str = StrField(primary=True)
    name: str = StrField(display=True)
    fields: list = ListField(field_type=DictField)

    @classmethod
    def objects(cls,
                filters: Union[Filter, list] = None,
                limit: int = 1000,
                offset: int = None,
                **kwargs):
        filters = cls._get_filter(filters, kwargs)
        response = api.RvisionAPI().get_task_types(filters=filters,
                                                   limit=limit,
                                                   offset=offset)

        return [cls(elem, sync=True) for elem in response]
