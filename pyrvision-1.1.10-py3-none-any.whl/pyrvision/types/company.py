from datetime import datetime
from typing import Union

from .. import api
from ..utils import Filter
from .base import RvisionObject
from .fields import IntField, StrField, DictField, TextField, ObjectField, ListField, DateTimeField


class Company(RvisionObject):
    id: int = IntField(primary=True)
    name: str = StrField(display=True)
    uuid: str = StrField(primary=True)
    createdAt: datetime = DateTimeField()
    updatedAt: datetime = DateTimeField()

    @classmethod
    def objects(cls,
                filters: Union[Filter, list] = None,
                limit: int = 1000,
                start: int = None,
                **kwargs):
        filters = cls._get_filter(filters, kwargs)
        response = api.RvisionAPI().get_companies(filters=filters,
                                                  limit=limit,
                                                  start=start)

        return [cls(elem) for elem in response]

    def push(self):
        raise NotImplementedError
