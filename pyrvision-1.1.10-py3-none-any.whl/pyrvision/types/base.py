import abc
import json
from typing import Dict, TypeVar, Type, List
from collections import OrderedDict

from .. import api
from .fields import BaseField, Field
from ..utils import Filter
from ..utils import exceptions


TObj = TypeVar('TObj', bound='RvisionObject')


class RvisionObject:
    def __new__(cls, data: dict = None, *args, **kwargs):
        cls._fields = cls._get_fields()
        instance = super().__new__(cls)
        return instance

    def __init__(self, values=None, sync=False, **kwargs):
        values = values if values else {}
        values = {**values, **kwargs}
        self.values = {}
        self.is_sync = sync
        self._api = api.RvisionAPI()
        self._set_values(values, sync)

    def __getitem__(self, item):
        if item in self._fields:
            return self._fields[item].get_value(self)
        if item in self.values:
            return self.values[item]
        raise AttributeError('Аттрибут не найден')

    def __repr__(self):
        display_fields = OrderedDict(**self._display_fields, **self._primary_fields)
        display_string = [f'{name}={value}' for name, value in display_fields.items()]
        return f'{self.__class__.__name__}({", ".join(display_string)})'

    def __str__(self):
        return self.as_json(human_readable=True)

    def __eq__(self, other):
        if not isinstance(other, type(self)):
            return False

        for name, field in self._fields.items():

            if field.primary \
                    and self.values.get(field.name) is not None\
                    and self.values.get(field.name) == other.values.get(field.name):
                return True

        return False

    @classmethod
    def objects(cls, *args, **kwargs):
        pass

    @classmethod
    def get(cls: Type[TObj], *args, **kwargs) -> TObj:
        try:
            objects = cls.objects(*args, **kwargs)
        except exceptions.RequestError:
            raise exceptions.ObjectDoesNotFound
        if len(objects) == 0:
            raise exceptions.ObjectDoesNotFound
        if len(objects) > 1:
            raise exceptions.ImpossibleDefineUniqueObject
        return objects[0]

    # @abc.abstractmethod
    def _create(self):
        pass

    # @abc.abstractmethod
    def _update(self):
        pass

    def push(self, *args, **kwargs):
        if self.values.get('uuid') is not None:
            response = self._update()

        else:
            try:
                object_ = self._get_unique_object(*args, **kwargs)
                self.values = {**object_.values, **self.values}
                response = self._update()

            except exceptions.ObjectDoesNotFound:
                response = self._create()

        self._set_values(response)

        return self

    def pull(self, *args, **kwargs):
        object_ = self._get_unique_object(*args, **kwargs)
        self.values = object_.values

        return self

    def _delete(self):
        pass

    def _get_unique_object(self, *args, **kwargs):
        try:
            object_ = self.get(filters=self._primary_filter, *args, **kwargs)
        except exceptions.PrimaryFieldNotExist:
            raise exceptions.ObjectDoesNotFound
        return object_

    def _set_values(self, values, sync=False):
        for name, value in values.items():
            field = self._fields.get(name)

            if field is not None:
                field.set_value(self, value, sync)

    def sync(self):
        if not self.is_sync:
            try:
                self.pull()
            except AttributeError:
                pass

        self.is_sync = True

    def to_python(self, export=False, human_readable=False):
        result = {}
        for name, value in self.values.items():
            # Filter empty values
            if value is None or value == []:
                continue
            # Export field values
            if name in self._fields:
                field = self._fields[name]
                if export:
                    if field.immutable:
                        continue
                    if field.import_only:
                        continue
                if not human_readable:
                    value = field.export(self)
                else:
                    value = repr(field.get_value(self))

            result[name] = value

        return result

    def as_json(self, human_readable=False):
        if human_readable:
            return json.dumps(self.to_python(), ensure_ascii=False, indent=4)
        else:
            return json.dumps(self.to_python())

    def copy(self, *args, **kwargs):
        value = {key: value for key, value in self.values.items()
                 if key not in self._primary_fields.keys()}
        return type(self)(values=value, *args, **kwargs)

    @property
    def _primary_fields(self):
        return {name: field.get_value(self) for name, field in self._fields.items() if field.primary}

    @property
    def _display_fields(self):
        return {name: field.get_value(self) for name, field in self._fields.items() if field.display}

    @property
    def _primary_filter(self):
        primary_fields = {name: value for name, value in self._primary_fields.items() if value is not None}

        if primary_fields:
            filters = Filter()

            for name, value in primary_fields.items():
                filters.add(name=name, value=value).get()

            return filters
        else:
            raise exceptions.PrimaryFieldNotExist("Ключевые поля отсутствуют или не заполнены")

    @classmethod
    def _get_fields(cls) -> Dict[str, Field]:
        attrs = {}
        for base in cls.mro():
            attrs.update(vars(base))
        attrs.update(vars(cls))
        fields = {value.name: value for value in attrs.values() if isinstance(value, BaseField)}
        return fields

    @staticmethod
    def _get_filter(filter: Filter = None, kwargs: dict = None):
        if filter:
            if isinstance(filter, Filter):
                filter = filter.get()
            return filter
        if kwargs:
            return Filter(**kwargs).get()
        return None

