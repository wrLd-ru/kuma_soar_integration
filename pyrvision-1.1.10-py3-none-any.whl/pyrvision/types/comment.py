from datetime import datetime

from .fields import IntField, StrField, DateTimeField
from .base import RvisionObject


class Comment(RvisionObject):
    id: int = IntField()
    login: str = StrField(display=True)
    text: str = StrField(display=True)
    create_time: datetime = DateTimeField()




