import mimetypes
from datetime import datetime
from typing import List, Union

from .. import api
from ..utils import Filter
from .base import RvisionObject
from .user import User
from .company import Company
from .comment import Comment
from .incident_files import IncidentFile
from .fields import StrField, DictField, TextField, ObjectField, ListField, DateTimeField, CatalogField, IntField


class Incident(RvisionObject):
    identifier: str = StrField(primary=True)
    uuid: str = StrField(primary=True)

    action: str = DictField(export_key='name', import_only=True)
    actions: list = ListField(field_type=CatalogField, export_key='name', import_only=True)
    description: str = TextField()
    files: str = ListField(base=IntField, import_only=True)
    imp_level_fin: str = IntField()
    imp_level_qt: Union[dict, str] = CatalogField(export_key='name')
    type_group: str = StrField()
    type: Union[dict, str] = CatalogField(export_key='name')

    company: Company = ObjectField(base=Company, export_key='name')
    incident_creator: User = ObjectField(base=User, aliases={'name': 'login'}, export_key='name')
    incident_owner: User = ObjectField(base=User, aliases={'name': 'login'}, export_key='name')

    category: Union[dict, str] = CatalogField(export_key='name')
    level: Union[dict, str] = CatalogField(export_key='name')
    location: List[Union[dict, str]] = ListField(field_type=CatalogField, export_key='name')
    status: Union[dict, str] = CatalogField(export_key='name')

    creation: datetime = DateTimeField()
    updated: datetime = DateTimeField()
    closure_date: datetime = DateTimeField()
    deadline_date: datetime = DateTimeField()
    detection_date: datetime = DateTimeField()
    occur_date: datetime = DateTimeField()

    causes: List[dict] = ListField(field_type=CatalogField, export_key='name')
    rel: List[dict] = ListField(field_type=DictField, import_only=True)

    @classmethod
    def objects(cls,
                filters: Union[Filter, list] = None,
                limit: int = None,
                offset: int = None,
                **kwargs):
        filters = cls._get_filter(filters, kwargs)
        response = api.RvisionAPI().get_incidents(filters=filters,
                                                  limit=limit,
                                                  offset=offset)

        return [cls(elem) for elem in response]

    def _update(self):
        return self._api.create_update_incident(data=self.to_python(export=True))

    def _create(self):
        return self._api.create_update_incident(data=self.to_python(export=True))

    def add_file(self, filename: [str], file: [bytes] = None, path: [str] = None):
        if path:
            file = open(path, 'rb')

        mime, _ = mimetypes.guess_type(filename)
        mime = mime if mime else 'text/plain'

        return self._api.add_file_to_incident(self.uuid, file, filename, mime)

    def get_linked_incidents(self):
        response = self._api.get_linked_incidents(self.identifier)
        linked_incidents = {elem["link"]["name"]: [] for elem in response}
        for elem in response:
            linked_incidents[elem["link"]["name"]].append(type(self)(values=elem))
        return linked_incidents

    def link_incident(self, incident: "Incident", link: str):
        response = self._api.link_incident(
            identifier_linking=self.identifier,
            identifier_linked=incident.identifier,
            link=link
        )
        return response

    def get_files(self):
        response = self._api.get_files_metadata_of_incident(self.identifier)
        return [IncidentFile(values=elem) for elem in response]

    def get_comments(self):
        response = self._api.get_comments(self.identifier)
        return [Comment(values=elem) for elem in response]

    def send_comments(self, text):
        response = self._api.send_comments(self.identifier, text)
        return response



