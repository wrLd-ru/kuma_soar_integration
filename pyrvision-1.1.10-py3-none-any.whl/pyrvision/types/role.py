from datetime import datetime
from typing import Union

from .. import api
from ..utils import Filter
from .base import RvisionObject
from .fields import IntField, StrField, TextField, DateTimeField


class Role(RvisionObject):
    id: int = IntField(primary=True)
    name: str = StrField(display=True)
    uuid: str = StrField()
    description: str = TextField()
    type: str = StrField()
    createdAt: datetime = DateTimeField()
    updatedAt: datetime = DateTimeField()

    @classmethod
    def objects(cls,
                filters: Union[Filter, list] = None,
                limit: int = 1000,
                start: int = None,
                **kwargs):
        filters = cls._get_filter(filters, kwargs)
        response = api.RvisionAPI().get_roles(filters=filters,
                                              limit=limit,
                                              start=start)

        return [cls(elem) for elem in response]
