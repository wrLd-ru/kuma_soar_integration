from datetime import datetime
from typing import Optional

from .fields import IntField, StrField, DateTimeField
from .base import RvisionObject


class IncidentFile(RvisionObject):
    id: int = IntField(primary=True)
    filename: str = StrField()
    name: str = StrField()
    description: str = StrField()
    size: int = IntField()
    type: str = StrField()
    md5: str = StrField()
    sha1: str = StrField()
    add_date: datetime = DateTimeField()

    def get_data(self) -> str:
        return self._api.get_file_by_id(self.id)

    def download(self, filename: Optional[str] = None):
        filename = filename if filename else self.filename
        data = self._api.get_file_by_id(self.id)

        with open(filename, 'wb') as file:
            file.write(data)


