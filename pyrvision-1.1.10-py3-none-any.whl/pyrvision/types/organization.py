from datetime import datetime
from typing import Union

from .. import api
from ..utils import Filter, exceptions
from .base import RvisionObject
from .company import Company
from .user import User
from .fields import IntField, StrField, TextField, DateTimeField, ListField, ObjectField


class Organization(RvisionObject):
    uuid = StrField(primary=True)
    type_id = IntField()
    name = StrField(display=True)
    parent_name = StrField(import_only=True)
    links = StrField(import_only=True)
    id = IntField(primary=True)
    company_id = IntField()
    company = ObjectField(base=Company, export_key='uuid')
    admin = ListField(field_type=ObjectField, base=User, export_key='id')
    auditor = ListField(field_type=ObjectField, base=User, export_key='id')
    description = TextField()
    compliance_manager = ListField(field_type=ObjectField, base=User, export_key='id')
    updatedAt: datetime = DateTimeField(import_only=True)

    @classmethod
    def objects(cls,
                filters: Union[Filter, list] = None,
                limit: int = 1000,
                start: int = None,
                **kwargs):
        filters = cls._get_filter(filters, kwargs)
        response = api.RvisionAPI().get_organization(filters=filters,
                                                     limit=limit,
                                                     start=start)

        return [cls(elem) for elem in response]

    def _create(self):
        return self._api.create_organization(self.to_python(export=True))

    def _update(self):
        return self._api.update_organization(uuid=self.uuid, data=self.to_python(export=True))

