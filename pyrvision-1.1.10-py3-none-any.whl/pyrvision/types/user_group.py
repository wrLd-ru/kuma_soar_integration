from datetime import datetime
from typing import List, Union

from .. import api
from ..utils import Filter
from .base import RvisionObject
from .company import Company
from .role import Role
from .fields import IntField, StrField, BoolField, TextField, ObjectField, ListField, DateTimeField


class UserGroup(RvisionObject):
    id: int = IntField(immutable=True, primary=True)
    name: str = StrField(display=True)
    description: str = TextField()
    default_interface_user_id: int = IntField()
    fixed_tabs: bool = BoolField()
    all_companies: bool = BoolField()
    uuid: str = StrField(immutable=True, primary=True)
    company_id: List[int] = ListField(field_type=IntField)
    company_ids: List[int] = ListField(field_type=IntField, immutable=True)
    companies: List[Company] = ListField(field_type=ObjectField,
                                         base=Company,
                                         on_change='_sync_companies',
                                         import_only=True,
                                         export_fields=['uuid', 'id', 'name'])
    roles: List[Role] = ListField(field_type=ObjectField, base=Role, immutable=True)
    updatedAt: datetime = DateTimeField(immutable=True)
    createdAt: datetime = DateTimeField(immutable=True)

    @classmethod
    def objects(cls,
                filters: Union[Filter, list] = None,
                limit: int = 1000,
                start: int = None,
                **kwargs):
        filters = cls._get_filter(filters, kwargs)
        response = api.RvisionAPI().get_user_groups(filters=filters,
                                                    limit=limit,
                                                    start=start)

        return [cls(elem) for elem in response]

    def _create(self):
        return self._api.create_user_group(data=self.to_python(export=True))

    def _update(self):
        return self._api.create_user_group(data=self.to_python(export=True))

    def _sync_companies(self):
        if self.values.get('companies') is not None:
            self.company_id = [company.id for company in self.companies]
