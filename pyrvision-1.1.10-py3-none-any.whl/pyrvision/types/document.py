from datetime import datetime
from typing import Union, List
from dataclasses import dataclass

from .. import api
from ..utils import Filter
from .base import RvisionObject
from .user import User
from .company import Company
from .document_type import DocumentType
from .fields import IntField, StrField, TextField, ObjectField, DateTimeField, BoolField, ListField, DictField


class ReviewPeriod:
    weekly = 'weekly'
    monthly = 'monthly'
    quarterly = 'quarterly'
    annually = 'annually'
    every_2_years = 'every_2_years'
    evert_3_years = 'evert_3_years'
    every_5_years = 'every_5_years'


class AccessLevel:
    change = 'change'
    view = 'view'


class DocumentStatus(RvisionObject):
    id: int = IntField()
    display_value: str = StrField()


class WorkgroupMember(User):
    access_level: str = StrField()


class Document(RvisionObject):
    uuid: str = StrField(import_only=True, primary=True)
    id: int = IntField(import_only=True)
    identifier: str = StrField()
    company: Company = ObjectField(base=Company, export_fields=['uuid'])
    type: DocumentType = ObjectField(base=DocumentType, export_fields=['uuid'])
    description: str = TextField()
    status: str = ObjectField(base=DocumentStatus, export_fields=['id'])
    name: str = StrField(display=True)
    create_time: datetime = DateTimeField(import_only=True)
    update_time: datetime = DateTimeField(import_only=True)
    approve_date: datetime = DateTimeField()
    approver: str = StrField()
    expire_date: datetime = DateTimeField()
    no_expire_date: bool = BoolField()
    assignee: User = ObjectField(base=User, export_fields=['uuid'])
    review_date: datetime = DateTimeField()
    notify_before: int = IntField()
    review_period: str = StrField()
    allow_read_only_for_all: bool = BoolField()
    files: list = ListField(field_type=DictField)
    workgroup: List[WorkgroupMember] = ListField(field_type=ObjectField,
                                                 base=WorkgroupMember,
                                                 export_fields=['uuid', 'access_level'],
                                                 on_change='_exclude_owner')

    @classmethod
    def objects(cls,
                filters: Union[Filter, list] = None,
                limit: int = None,
                offset: int = None,
                **kwargs):
        filters = cls._get_filter(filters, kwargs)
        response = api.RvisionAPI().get_documents(filters=filters,
                                                  limit=limit,
                                                  offset=offset)
        return [cls(values=elem, sync=True) for elem in response]

    def _create(self):
        return self._api.update_document(self.values.get('uuid'), self.to_python(export=True))

    def _update(self):
        return self._api.create_documents(self.to_python(export=True))

    def add_workgroup_member(self, user: User, access_level: str = AccessLevel.view):
        member = WorkgroupMember(user=user, access_level=access_level)
        workgroup = self.workgroup
        workgroup.append(member)
        self.workgroup = workgroup

    def _exclude_owner(self):
        pass
