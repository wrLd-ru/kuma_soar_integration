from datetime import datetime
from typing import Union, List

from .. import api
from ..utils import Filter
from .base import RvisionObject
from .user import User
from .company import Company
from .fields import IntField, StrField, TextField, ObjectField, DateTimeField, BoolField, ListField, DictField


class DocumentField(RvisionObject):
    id: int = IntField()
    name: str = StrField()


class DocumentType(RvisionObject):
    id: int = IntField()
    name: str = StrField(display=True)
    uuid: str = StrField()
    fields: List[ObjectField] = ListField(field_type=ObjectField)

    @classmethod
    def objects(cls,
                filters: Union[Filter, list] = None,
                limit: int = None,
                offset: int = None,
                **kwargs):
        filters = cls._get_filter(filters, kwargs)
        response = api.RvisionAPI().get_documents_types(filters=filters,
                                                        limit=limit,
                                                        offset=offset)
        return [cls(values=elem, sync=True) for elem in response]

    def pull(self):
        response = self._api.get_document_type_params(self.uuid)
        self._set_values(response)

        return self
