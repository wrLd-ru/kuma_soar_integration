from .. import api
from .base import RvisionObject
from .fields import IntField, StrField, TextField


class CustomAssetsType(RvisionObject):
    id: int = IntField(primary=True)
    name: str = StrField(display=True)
    description: str = TextField()
    asset_class: str = StrField(name='class')
    tag: str = StrField()

    @classmethod
    def objects(cls, **kwargs):
        response = api.RvisionAPI().get_custom_assets_types()
        return [cls(elem, sync=True) for elem in response if cls.check_filter(elem, kwargs)]

    @staticmethod
    def check_filter(elem: dict, requirements: dict):
        return all([elem[key] == value for key, value in requirements.items()])







