import json
import requests


class BaseRvisionError(Exception):
    pass


class ObjectDoesNotFound(BaseRvisionError):
    pass


class ImpossibleDefineUniqueObject(BaseRvisionError):
    pass


class RequestError(BaseRvisionError):
    def __init__(self, request: requests.PreparedRequest, message: str):
        self.url = request.url
        self.method = request.method
        try:
            self.body = json.loads(request.body)
        except TypeError:
            self.body = None
        self.message = message
        super().__init__(self.message)

    def __str__(self):
        return f'{self.message} \n'\
               f'Method: {self.method} \n' \
               f'Url: {self.url} \n' \
               f'Data: {self.body}'


class BadRequest(RequestError):
    pass


class NotFound(RequestError):
    pass


class FieldError(BaseRvisionError):
    def __init__(self, name, value, **kwargs):
        self.name = name
        self.value = value

        for name, value in kwargs.items():
            setattr(self, name, value)

    def __str__(self):
        return f'\nfield: {self.name} \n' \
               f'value: {self.value} \n'


class TransformError(FieldError):
    def __str__(self):
        return super().__str__() + f'type: {getattr(self, "type").__name__}'


class FormatTransformError(FieldError):
    def __str__(self):
        return super().__str__() + f'format: {getattr(self, "format")}'


class SerializeError(TransformError):
    pass


class DeserializeError(TransformError):
    pass


class TryToSetImmutableField(FieldError):
    pass


class ObjectToPythonIsAbsent(FieldError):
    pass


class PrimaryFieldNotExist(BaseRvisionError):
    pass