import json
from typing import Any


class Filter:
    def __init__(self, **kwargs):
        self.filters = []
        for key, value in kwargs.items():
            self.add(key, value)

    def __repr__(self):
        return f'Filter({self.get()})'

    def add(self, name: str, value: Any, operator='='):
        self.filters.append({
            "property": name,
            "operator": operator,
            "value": value
        })
        return self

    def get(self):
        return self.filters




